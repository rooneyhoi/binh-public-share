---
name: Warm Celebration
colors:
  surface: '#fcf9f5'
  surface-dim: '#dcdad6'
  surface-bright: '#fcf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ef'
  surface-container: '#f0ede9'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e5e2de'
  on-surface: '#1c1c1a'
  on-surface-variant: '#57423e'
  inverse-surface: '#31302e'
  inverse-on-surface: '#f3f0ec'
  outline: '#8a716c'
  outline-variant: '#dec0ba'
  surface-tint: '#a43c28'
  primary: '#a43c28'
  on-primary: '#ffffff'
  primary-container: '#ff7f66'
  on-primary-container: '#731808'
  inverse-primary: '#ffb4a5'
  secondary: '#5b3cdd'
  on-secondary: '#ffffff'
  secondary-container: '#7459f7'
  on-secondary-container: '#fffbff'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c7a000'
  on-tertiary-container: '#483900'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad3'
  primary-fixed-dim: '#ffb4a5'
  on-primary-fixed: '#3f0400'
  on-primary-fixed-variant: '#842413'
  secondary-fixed: '#e5deff'
  secondary-fixed-dim: '#c9bfff'
  on-secondary-fixed: '#1a0063'
  on-secondary-fixed-variant: '#441cc8'
  tertiary-fixed: '#ffe086'
  tertiary-fixed-dim: '#edc22b'
  on-tertiary-fixed: '#231b00'
  on-tertiary-fixed-variant: '#574500'
  background: '#fcf9f5'
  on-background: '#1c1c1a'
  surface-variant: '#e5e2de'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  section-gap-desktop: 120px
  section-gap-mobile: 64px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
---

## Brand & Style

This design system centers on a "Warm Minimalist" aesthetic designed to evoke joy, calm, and inclusivity. The brand personality is celebratory yet grounded, moving away from high-energy urgency toward a thoughtful, gift-giving experience. 

The style utilizes a "Soft Modern" approach:
- **Calm Minimalism:** Generous whitespace (or "cream-space") to reduce cognitive load and emphasize curated gift items.
- **Micro-Joy Moments:** Subtle decorative accents such as floating stars and soft confetti clusters are used sparingly to highlight achievements or specific calls to action.
- **Inclusive Accessibility:** While the palette is playful, high contrast is maintained for all text elements to ensure readability across all age groups, from children to seniors.
- **Soft Geometry:** Edges are rounded and approachable, avoiding any sharp "corporate" feeling in favor of a more "lifestyle" atmosphere.

## Colors

The palette is anchored by a warm, paper-like foundation to create a tactile, inviting feel.

- **Primary (Coral):** Used for main conversion points and the brand's heart. It provides energy without being aggressive.
- **Secondary (Violet):** Used for "special" actions like sharing a list or highlighting a luxury item. It adds a touch of magic and depth.
- **Tertiary (Golden Yellow):** Reserved for celebratory accents, star icons, and reviews. 
- **Neutral (Soft Cream):** The background color for the entire experience, providing a much softer visual experience than pure white.
- **Text:** A deep charcoal-brown (#2D2926) is used instead of pure black to maintain the warmth of the palette while ensuring AAA contrast.

## Typography

The typography strategy pairs a friendly, rounded sans-serif for personality with a highly legible grotesque for utility.

- **Headlines:** Plus Jakarta Sans provides a contemporary, friendly "bounce." Use tight letter spacing for large display text to create a more impactful, editorial look.
- **Body:** Inter handles all long-form text, product descriptions, and functional labels. It ensures that the "Wall of Love" (reviews) and product lists are effortless to read.
- **Scaling:** Mobile headlines scale down to prevent awkward word breaks while maintaining a clear visual hierarchy.

## Layout & Spacing

This design system follows a **Fluid Grid** model with a mobile-first philosophy.

- **Mobile (Base):** Uses a single-column layout with 20px side margins. Cards and components stretch to full width minus margins.
- **Desktop:** Transitions to a 12-column grid with a maximum container width of 1200px. 
- **Rhythm:** An 8px base unit drives all spacing. Elements are spaced in multiples of 8 (16, 24, 32, 48, 64) to maintain vertical rhythm.
- **Section Breaks:** Generous vertical padding between sections (up to 120px on desktop) reinforces the minimalist, calm aesthetic and allows "star" and "confetti" decorative elements to breathe.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Soft Ambient Shadows**.

- **Surface Levels:** 
  - Level 0: Background (#FDFAF6).
  - Level 1: Cards and Containers (#FFFFFF).
- **Shadows:** Use extremely diffused, low-opacity shadows. Avoid harsh black shadows; instead, use a slight tint of the primary color (e.g., `rgba(255, 127, 102, 0.08)`) for shadows on primary elements to maintain the warm glow.
- **Depth:** Interactive elements (buttons, product cards) use a subtle lift on hover to signal playfulness and interactivity.

## Shapes

The shape language is consistently "Rounded" to align with the friendly brand personality.

- **Standard Elements:** 8px (0.5rem) radius for input fields and standard list items.
- **Large Elements:** 16px (1rem) for product cards and main containers.
- **Extra Large:** 24px (1.5rem) for hero sections and featured call-outs.
- **Buttons:** Use fully pill-shaped (999px) radii for primary CTAs to make them feel "squishable" and inviting.

## Components

- **Buttons:** Primary buttons are Coral (#FF7F66) with white text, pill-shaped, and feature a subtle shadow. Secondary buttons use a Violet (#7B61FF) outline.
- **Cards (Product Preview):** White background with a 16px border-radius and a soft ambient shadow. Price tags are highlighted in Golden Yellow (#FFD33D).
- **Chips:** Used for "Occasions" (e.g., "Birthday," "Wedding"). These should have a light background tint of the accent color (e.g., light violet) and bolded text.
- **Input Fields:** Large 16px text with a soft cream background and 1px border. On focus, the border transitions to Primary Coral.
- **Wall of Love:** Review cards use "Plus Jakarta Sans" for the reviewer's name and "Inter" for the quote, featuring a small Golden Yellow star icon as a decorative flourish.
- **Confetti/Stars:** These are SVG-based decorative components that appear behind the "Final CTA" and "Hero" sections, using the Primary, Secondary, and Tertiary colors.